# 网页动画实现规范（原理演示）

每章的 HTML 页面必须包含**至少一个能演示本章核心原理的动画**。以下是经过验证的实现约定与踩坑记录。

## 一、技术选型

| 需求 | 做法 |
|---|---|
| 画结构图 / 数据流 | 内联 SVG，用 `svgEl()` 助手创建元素 |
| 逐帧演示（如注意力四步） | `Player` 帧播放器 + `onFrame` 重绘 |
| 连续变化（如拖动滑块） | 重绘 + CSS `transition` 平滑过渡 |
| 旋转 / 位移 | `<g style="transform: rotate(deg)">`，**不要**改几何属性 |

**不引入任何外部库**。纯原生 SVG + CSS + JS，保证单文件可分发、离线可看。

## 二、必须遵守的规则

### 1. 主题跟随 IDE
- 浅色主题：浅底深字；深色主题：深底浅字。
- **所有形状必须显式设置 `fill`**，不要依赖颜色类名（未实现时会 fallback 成黑色，导致深色主题下看不见）。

### 2. SVG 属性动画的陷阱
CSS `transition` **不作用于** SVG 的几何属性（`x2`、`y2`、`height`、`cx` 等），
只作用于 CSS 属性（`transform`、`opacity`、`fill`、`stroke`）。

- ✅ 旋转：`<g style="transform: rotate(Xdeg); transform-origin: cx cy; transition: transform .35s">`
- ✅ 淡入淡出：`rect.style.opacity = ...`（有 transition 就平滑）
- ⚠️ 柱子高度变化：可以给 `rect` 加 `style.transition = "all .35s"` 后改 `y`/`height`——
  现代浏览器支持，但要做兜底；更稳的是重绘。
- ❌ 不要指望 `line.x2 = ...` 会平滑过渡。

### 3. 动画必须可交互
每个动画至少提供：`▶ 播放`、`上一步`、`下一步`。
关键参数（温度、rank、缩放系数、位置 m）做成 `<input type="range">` 滑块，
让学习者**自己拨动、自己观察**，这比自动播放有效得多。

### 4. 每屏只讲一件事
一个动画最多演示一个机制。复杂原理拆成 2–3 个并列的 `stage`，中间用文字过渡。

## 三、`Player` 播放器（见 `assets/course-common.js`）

```js
const p = new Player(1.2);                 // 帧率
p.load(framesArray);                       // 一组帧（任意数据）
p.onFrame = (frame, i, total) => { /* 重绘 */ };
wireControls(p, { play: "play", prev: "prev", next: "next" });
p.render();
```

`Player` 只负责调度，**重绘逻辑由各章自己写**——这保证了每章都能做出贴合原理的视觉。

## 四、页面骨架模板

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>第 NN 章 · 标题 · 课程名</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar">
  <a class="brand" href="index.html"><span class="dot">XX</span> 课程名</a>
  <span class="spacer"></span>
  <nav><a href="index.html">课程主页</a><a href="notebooks/NN_x.ipynb">配套 Notebook</a></nav>
</header>

<div class="layout">
  <aside class="side"></aside>          <!-- 由 chapters.js 填充 -->
  <main>
    <div class="chapter-head">
      <span class="eyebrow">第 NN 章 · 所属部分</span>
      <h1>标题</h1>
      <p class="lead">一句话说清这章要解决什么问题。</p>
      <div class="meta-row"><span class="tag">关键概念</span>…</div>
    </div>

    <section class="card">
      <h2>1. 背景与公式</h2>
      <pre><code>…核心公式…</code></pre>
    </section>

    <section class="card">
      <h2>2. 动画：…</h2>
      <div class="stage">
        <div class="stage-head"><span class="badge">动画</span><span class="t">标题</span></div>
        <svg id="demo" viewBox="0 0 680 300"></svg>
        <div class="controls">
          <button class="btn" id="play">▶ 播放</button>
          <button class="btn ghost" id="prev">上一步</button>
          <button class="btn ghost" id="next">下一步</button>
        </div>
      </div>
      <div class="callout key"><div class="ct">🔑 关键点</div>…</div>
    </section>

    <section class="card">
      <h2>3. 官方配图 / 数据</h2>
      <figure><img src="../images/xxx.jpg" alt="…"><figcaption>来源说明</figcaption></figure>
    </section>

    <section class="card">
      <h2>4. 动手提示</h2>
      <div class="callout tip"><div class="ct">✅ 动手提示</div>…</div>
    </section>

    <div class="pager"></div>           <!-- 由 chapters.js 填充 -->
  </main>
</div>

<script src="assets/common.js"></script>
<script src="assets/chapters.js"></script>
<script>
bootChapter("NN");
/* 本章动画逻辑 */
</script>
</body>
</html>
```

## 五、可用的 CSS 组件（见 `assets/course-style.css`）

`.card`、`.callout`（`.tip` / `.warn` / `.note` / `.key`）、`.stage`、`.controls`、`.btn`（`.ghost`）、
`.slider`、`.legend`、`.checklist`、`.pager`、`figure`、`table`、`.grid-cards`、`a.chap`。
动画辅助类：`.flowline`（流动虚线）、`.pulse`、`.floaty`。

## 六、章节清单驱动

`assets/course-chapters.js` 里的 `CHAPTERS` 数组是唯一事实来源——
侧边栏、翻页、主页卡片全部由它渲染。新增/调整章节只改这一处。

## 七、校验

```bash
node scripts/check_html_js.mjs   # 抽取每个 <script> 内联块，用 new Function(code) 只编译不执行
```

这能在几秒内抓出所有 JS 语法错误，比逐个打开浏览器快得多。
