# 引导式 Notebook 编写规范

每章的 Notebook 是学习者**动手的地方**。核心原则：**先给工具，再给提示，最后留白。**

## 一、强制三段式结构

```
# 第 NN 章 · 标题
> 📄 配套动画网页：../NN_xxx.html   （先看动画再来写代码）

## 🎯 本章目标
- …（3–5 条，动词开头）

---
# 第一部分 · 基础函数演示
> 这一部分可以直接运行。先熟悉本章要用的 Python / PyTorch API。

### 1.1 <函数名> —— 一句话说明
<md：解释这个函数干什么、参数、返回>
<code：可直接运行的最小示例，必须 print 出结果>

### 1.2 …

---
# 第二部分 · 动手实现（只给提示，留白给你）
> 下面每一节都没有答案。请根据提示 + 第一部分演示过的函数自己写。

### 2.1 实现 <类/函数名>
<md：用文字讲清要求、算法步骤、易错点>
<blank：留白代码块>

---
# 第三部分 · 自测与思考
- [ ] …
**思考题**：…
```

## 二、第一部分怎么写

- 一个 API 一小节，**必须能直接运行**并打印可见结果。
- 优先演示「形状」：`print(x.shape)` 反复出现，形状是深度学习里最容易错的地方。
- 涉及易错点时**故意展示错误**再修正。例：
  ```python
  try:
      (x - m1).shape          # 广播失败
  except RuntimeError as e:
      print("广播失败：", e)
  ```
- 涉及外部库时用 `try/except ImportError` 包裹，并在缺依赖时打印
  「请先执行 `uv sync`」+ 纯 Python 降级演示，避免学习者一上来就看到 traceback。

## 四、留白代码块模板（核心）

由 `scripts/notebook_builder.py` 的 `blank()` 生成：

```python
# ======== 你的实现：<名称> ========
#
# 【要求】
#   - <可验证的要求 1>
#   - <可验证的要求 2>
#
# 【可用到的函数 / 方法】
#   - `torch.rsqrt`
#   - `Tensor.mean(dim=-1, keepdim=True)`
#
# 【补充】<可选的进阶说明>
#
# 提示：先想清楚输入输出的形状，再动手。
#
# ↓↓↓ 在这里写你的代码 ↓↓↓


```

要点：
1. **只给注释**，绝不写 `pass` 占位符或部分实现（否则学习者会去补而不是去建）。
2. 【要求】要**可验证**——写完能自己判断对错（形状、数值、性质）。
3. 【可用到的函数 / 方法】要**指向第一部分演示过的内容**，形成闭环。
4. 模型部分（网络结构）**只给文字提示**，不给任何伪代码骨架。
5. 【要求】里要写清**确切的函数名与签名**——测试块要靠它来调用你的实现。

## 四之一、每个留白后面必须跟一个测试块

**有留白就必须有验证。** 读者写完不知道对不对，学习闭环就是断的。

在 Part 2 开头放一个 `testkit()` 单元格（定义 `check / close / same / summary`），
然后每个留白后面放一个 `test(...)`：

```python
blank("RMSNorm", [...], [...]),
test("RMSNorm", '''def _t():
    torch.manual_seed(0)
    m = RMSNorm(8)
    x = torch.randn(2, 5, 8)
    y = m(x)
    assert tuple(y.shape) == (2, 5, 8), f"输出形状应与输入一致，得到 {tuple(y.shape)}"
    close(y.pow(2).mean(-1).sqrt().mean().item(), 1.0, tol=1e-2,
          msg="weight 初始为 1 时，归一化后每个向量的 RMS 应约等于 1")
    close(m(x * 7.3), y, tol=1e-3, msg="应具有尺度不变性：RMSNorm(k*x) == RMSNorm(x)")
check("RMSNorm 形状 / 数值 / 尺度不变性", _t)'''),
```

Part 2 末尾放一个 `summary_cell()`。

### 测试块的五条硬规矩

1. **没写也不能报错。** `check()` 必须捕获 `NameError` 并打印「⏸ 未实现」，
   而不是让 traceback 炸掉整格。三种状态：`✅ 通过 / ❌ 失败 / ⏸ 未实现`。
2. **断言信息要具体。** 不要 `assert y.shape == (2,5,8)`，
   要 `assert ... , f"输出形状应为 (2,5,8)，得到 {tuple(y.shape)}"`——直接告诉读者错在哪。
3. **只测行为，不测写法。** 断言形状、性质（尺度不变性、因果性、保范数）、
   与独立公式/`torch` 内置实现的一致性。**不要**断言内部变量名或实现细节，
   否则换个正确写法就过不了。
4. **用性质测试代替数值硬编码。** 优先断言「因果掩码下改最后一个位置不影响前面」
   「旋转保范数」「B 零初始化时输出为 0」这类**不变量**，比死记数值更有教学价值。
5. **把「坑」变成测试。** 最容易犯的错直接写成断言：
   忘写 `detach()` → 断言 `logp_old.grad is None`；忘写 `keepdim` → 断言形状；
   残差漏加 → 把子层输出投影置零后断言输出等于输入。

### 依赖前面章节时，给「参考实现」而不是让读者猜

组装类章节（如 Block / 完整模型）依赖前面几章的组件。用 `deps()` 提供一份
**精简的参考实现**，并注明「不是让你抄，而是让本章可以独立测试」：

```python
*deps("""### 8.6 前置依赖：`RMSNorm` / `Attention` / `FeedForward`

组装需要前面几章的零件。下面给一份精简的参考实现，让本章可以独立测试「组装」这件事。
如果你前面几章已经写好了，欢迎换成你自己的版本。""",
'''class RMSNorm(nn.Module):
    ...
'''),
```

否则前面某章的一个小 bug 会让本章的测试失败，把读者引向错误的排查方向。

### 必做：用「答案实现」反向校验测试

测试本身也会写错（断言过严、公式抄错、布局搞混）。交付前**必须**用一份正确的
参考实现把所有测试跑一遍：

```bash
# answers.py 放在项目目录之外，避免泄漏答案
python scripts/verify_tests.py notebooks/ /path/outside/project/answers.py
```

判定标准：每个 notebook 的 `fail=0 skip=0`。这一步抓出过真实的设计 bug——
例如 `repeat_kv` 约定 `[B,S,H,D]` 布局，而 `causal_attention` 却按 `[B,H,S,D]` 写，
两者单独看都「对」，放一起才暴露。

## 四、每章至少留 2 个空白单元

建议配比：**每章 4–6 个演示单元 + 2–4 个留白单元**。
留白单元要覆盖本章的「核心产出」，而不是边角料。

## 四之二、官方配图必须同时进网页和 Notebook

如果主题有官方配图（架构图、损失曲线、结构示意），**网页和 Notebook 里都要放**——
学习者常常只开 Notebook，缺图会失去关键视觉锚点。

用 `img()` 助手插入，路径相对 `notebooks/` 目录：

```python
img(
    ("../images/LLM-structure.jpg", "MiniMind 稠密模型结构（Transformer Decoder-Only）"),
    ("../images/pretrain_loss.jpg", "预训练损失曲线——loss 稳定下降即训练正常"),
)
```

分配原则：
- **总览章**放全套图（架构、数据集、生态、评测），让学习者先建立全局印象。
- **组件章**放架构图并加一句「本组件在图中的哪个位置」，形成定位感。
- **训练章**放对应阶段的损失曲线。
- 找不到对应图时，宁可复用最相关的那张并说明「它在整体中的位置」，也不要空着。

## 五、第三部分怎么写

- `- [ ]` 检查清单：每条对应一个可自测的结论。
- **思考题**：引导思考边界情况（「如果去掉 X 会怎样？」），不要有标准答案。

## 六、用生成器批量产出

手写 `.ipynb` 的 JSON 极易出错（转义、换行、结构）。**始终用 Python 生成器**：

```python
from notebook_builder import md, code, blank, header, goals, part1, part2, part3, save

cells = [
    header(3, "RMSNorm", "第二部分 · 模型", "03_rmsnorm.html", "一句话导语"),
    goals([...]),
    md("## 📖 背景\n\n…"),
    part1(),
    md("### 3.1 `torch.rsqrt`"),
    code("import torch\nprint(torch.rsqrt(torch.tensor([4.0])))"),
    part2(),
    md("### 3.5 实现 `RMSNorm`\n\n**要求**：…"),
    blank("RMSNorm", ["继承 nn.Module", "…"], ["`torch.rsqrt`"]),
    part3(["…"], "**思考题**：…"),
]
save("03_rmsnorm.ipynb", cells)
```

把章节分成 3 个生成脚本（如 `build_notebooks_a/b/c.py`），避免单个文件过大。

## 七、校验三连（必做）

```bash
python scripts/validate_notebooks.py   # JSON 合法性 + nbformat 结构 + 每个代码单元 compile()
python scripts/run_notebooks.py        # 顺序执行所有「演示」单元（跳过留白单元），报告失败
node   scripts/check_html_js.mjs       # 网页内联 JS 语法
```

`run_notebooks.py` 会把工作目录切到 `notebooks/`，模拟 Jupyter 的运行环境
（这样 `../data/...` 之类的相对路径才能正确解析）。

> 交付前**必须**三个都通过。`run_notebooks.py` 能抓出所有「看起来对但一跑就错」的演示代码。
