---
name: guided-course-builder
description: 把一个技术主题（最典型的是"从零实现一个 LLM / 小语言模型"）拆成多个知识点章节，为每章同时产出「原理演示动画 HTML 网页」与「引导式 Jupyter Notebook」。Notebook 强制三段式：先用可运行代码演示本章所需函数，再用文字提示讲清要建什么，最后留出只有注释的空白代码块让学习者从零写。配套校验工具链保证网页 JS 与 Notebook 代码真能跑通。当用户提出"从零学习项目 / 分章教程 / 知识点拆解 / 教学网页加 Notebook / 留白练习 / 不要给答案让我自己写 / 把某项目拆成章节教学"这类需求时使用。也适用于为任意技术主题（算法、框架、论文复现）构建同类课程。
agent_created: true
---

# Guided Course Builder（分章引导式课程构建）

## 概述

用于构建「**看动画 → 学函数 → 自己写代码**」闭环的技术教学项目。核心特征：

- **分章拆解**：把一个大主题拆成 10–15 个知识点，每章独立成篇。
- **双产物**：每章 = 1 个动画网页 + 1 个引导式 Notebook。
- **留白教学**：核心实现只给文字提示，代码由学习者自己写。
- **可复现**：uv 管环境，校验脚本保证产物真能跑。

## 何时使用

- 用户要"从零学习 / 从零实现"某个技术主题，并要求分章节教学。
- 用户明确要求"只给提示，不给答案""留空白代码块让我自己写"。
- 用户要"每章配一个动画网页 + 一个 Notebook"。
- 用户想把某个开源项目（如 MiniMind、nanoGPT、tiny-universe）改造为教学课程。

**不适用**：只要一篇报告、只要一个 notebook、或要完整可直接运行的成品代码（本项目刻意不给答案）。

## 核心方法论

### 1. 先调研，再动笔

必须先从权威来源拿到：**真实代码结构、关键超参、官方配图、算法公式**。

```bash
# 拿到源码与官方配图（图片通常放在 images/）
git clone --depth 1 <repo-url> /tmp/<name>_src
```

逐行读核心源码（模型定义、训练脚本、数据集类），把**真实数值**写进课程
（层数、维度、头数、词表大小、学习率公式）。凭印象写会出错，也会让学习者对不上官方实现。

### 2. 拆章：基础 → 核心机制 → 应用/进阶

推荐三段式分组，约 15 章：

| 分组 | 章数 | 内容 |
|---|---|---|
| 基础 | 2 | 项目总览与环境、数据/分词流水线 |
| 核心机制 | 5–6 | 逐个组件：归一化 → 位置编码 → 注意力 → 前馈 → 稀疏化 → 组装 |
| 应用/进阶 | 5–7 | 训练各阶段：预训练 → 微调 → 参数高效 → 蒸馏 → 偏好对齐 → 强化学习 → 智能体 |

**拆章原则**：一个组件 = 一章；一个训练阶段 = 一章。每章必须能独立看懂。

### 3. 每章双产物

- `NN_xxx.html`（仓库根目录）：交互动画讲原理（详见 `references/html-animation-patterns.md`）
- `notebooks/NN_xxx.ipynb`：三段式引导（详见 `references/notebook-authoring.md`）

**官方配图必须同时出现在网页和 Notebook 里。** 学习者常常只开 Notebook，
缺图就丢了视觉锚点。总览章放全套图，组件章放架构图并标注「本组件在图中的位置」，
训练章放对应阶段的损失曲线。用 `img()` 助手插入（见 `references/notebook-authoring.md`）。

### 4. 留白必配测试块

**有留白就必须有验证。** 读者写完不知道对不对，学习闭环就是断的。

在 Part 2 开头放 `testkit()`（定义 `check / close / same / summary`），
每个留白后面放 `test(...)`，Part 2 末尾放 `summary_cell()`。

三种状态，且**没写代码时也不能报错**：

```
✅ 通过   RMSNorm 形状 / 数值 / 尺度不变性
❌ 失败   ... —— 输出形状应与输入一致，得到 (2, 5, 8)
⏸  未实现 ... —— name 'RMSNorm' is not defined
```

铁律：**只测行为，不测写法**。断言形状、不变量（尺度不变性 / 因果性 / 保范数）、
与独立公式或 `torch` 内置实现的一致性；把常见的「坑」直接写成断言
（忘 `detach()`、忘 `keepdim`、残差漏加…）。

### 5. 环境用 uv 管理

```bash
uv init --no-package <project>
# 写 pyproject.toml（依赖 + [dependency-groups] dev）
uv lock            # 只解析、不下载，秒级生成 uv.lock
uv sync            # 学习者执行，真正装依赖
```

`uv lock` 只做依赖解析不下载，适合快速产出锁文件。**不要**把 `uv.lock` 写进 `.gitignore`。

### 6. 校验四连（交付前必做）

```bash
python scripts/validate_notebooks.py   # JSON + nbformat + 每个代码单元 compile()
python scripts/run_notebooks.py        # 真跑所有非留白单元（含测试块，验证「未实现」路径不炸）
node   scripts/check_html_js.mjs       # 网页内联 JS 语法
python scripts/verify_tests.py notebooks/ <项目外>/answers.py   # 答案实现反向校验测试本身
```

最后一条最容易被忽略、却最不能省：**测试本身也会写错**。
必须用一份正确的参考实现把所有测试跑一遍，确认 `fail=0 skip=0`。
答案文件要放在项目目录之外，避免泄漏。

## 执行流程

### Step 0 · 调研

1. 用 WebSearch / WebFetch 找到项目官方仓库与文档。
2. `git clone --depth 1` 到临时目录。
3. 读核心源码，记录：架构组件清单、训练阶段清单、关键超参、官方图片文件名。
4. 列出配图 → 章节的映射关系（每张图都要有归宿）。

### Step 1 · 搭骨架

**网页直接放在仓库根目录**——这样它天然就是一个可托管的站点（见 Step 7 的原因）：

```
<project>/
├── index.html               # 课程主页（卡片式导航）
├── NN_xxx.html              # 每章一页（根目录）
├── assets/
│   ├── style.css            # 复制 assets/course-style.css
│   ├── common.js            # 复制 assets/course-common.js
│   └── chapters.js          # 复制 assets/course-chapters.js，改 CHAPTERS 数组 + REPO
├── .nojekyll                # 关闭 Jekyll，让 Pages 原样发布
├── images/                  # 官方配图（从 clone 的 images/ 拷过来）
├── data/                    # 必要的官方小文件（如 tokenizer.json）
├── notebooks/NN_xxx.ipynb
├── pyproject.toml / uv.lock / .python-version / .gitignore
├── README.md
└── tools/                   # 复制 scripts/ 下的脚本
```

网页里引用图片写 `images/xxx.png`；Notebook 里写 `../images/xxx.png`。两者都能解析。

### Step 2 · 共享资产

从本 skill 的 `assets/` 复制三份文件，把 `chapters.js` 里的 `CHAPTERS` 数组
改成实际章节清单（**这是侧边栏、翻页、主页卡片的唯一事实来源**）。

### Step 3 · 逐章写网页

按 `references/html-animation-patterns.md` 的骨架模板写。
每章至少 1 个动画；动画必须带「播放 / 上一步 / 下一步」+ 关键参数滑块。
把对应官方配图放进 `<figure>` 并标注来源。

### Step 4 · 用生成器批量产出 Notebook

按 `references/notebook-authoring.md` 写生成脚本（3 个文件分批），
用 `scripts/notebook_builder.py` 的
`md / code / blank / img / testkit / test / summary_cell / deps / header / goals / part1 / part2 / part3 / save`。

**绝对不要手写 .ipynb 的 JSON。**

顺序：`part2(...)` → `testkit()` → 每个 `blank(...)` 紧跟 `test(...)` → `summary_cell()`。

### Step 5 · 校验四连

全部通过才算完成。有失败就修，不要放过。特别是最后一条
（`verify_tests.py` 答案反向校验）——它验证的是「测试本身对不对」。

### Step 6 · 交付

- 写 README：课程地图、快速开始（uv 命令）、目录结构、校验命令、学习顺序建议，
  以及**测试块怎么用**（三种状态的示例输出）。
- 用 `present_files` 打开 `index.html` 与一个代表性章节页 + 一个 Notebook。

### Step 7 · 发布到 GitHub Pages（可选但常见）

**布局选择**：让**仓库根目录就是站点根目录**。这样网页里的 `images/xxx.png`
和 Notebook 里的 `../images/xxx.png` 都能同时解析到根目录的 `images/`——
如果改用 `/docs` 目录托管，`images/` 必须搬进 `docs/`，
Notebook 的 `../images/` 就会失效。这是踩过的坑。

步骤：

```bash
# 1. 网页放根目录，图片引用写成 images/xxx.png（不带 ../）
# 2. 加 .nojekyll（关闭 Jekyll，原样发布）
touch .nojekyll

# 3. 把所有页面右上角的「配套 Notebook」指向 GitHub 上的 .ipynb
python scripts/set_repo.py <owner>/<repo> main

# 4. 建仓 + 推送 + 开启 Pages（source = main / 根目录）
python scripts/publish.py <owner>/<repo>
```

站点地址形如 `https://<owner>.github.io/<repo>/`。

要点：
- Notebook 是 `.ipynb`，Pages 里不能直接渲染，所以链接要指向
  `https://github.com/<owner>/<repo>/blob/<branch>/notebooks/xxx.ipynb`。
- 仓库地址只写**一处**：`assets/chapters.js` 里的 `REPO` / `BRANCH` 常量，
  `set_repo.py` 负责同步到所有静态 HTML，避免 15 个文件里各写一遍。
- 先本地起个服务验证一遍再推：`python -m http.server 8000`，
  逐个检查 `index.html` / 章节页 / `assets/*` / `images/*` 都返回 200。

## 留白代码块的写法（最关键的约定）

```python
# ======== 你的实现：RMSNorm ========
#
# 【要求】
#   - 继承 nn.Module
#   - weight = nn.Parameter(torch.ones(dim))
#   - norm(x) = x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + eps)
#
# 【可用到的函数 / 方法】
#   - `torch.rsqrt`
#   - `Tensor.mean(dim=-1, keepdim=True)`
#
# 提示：先想清楚输入输出的形状，再动手。
#
# ↓↓↓ 在这里写你的代码 ↓↓↓


```

- **只给注释**，不写 `pass`，不写半成品骨架。
- 【要求】必须可自测（形状对、数值对、性质成立）。
- 【可用函数】必须指向第一部分演示过的 API，形成闭环。
- 模型结构部分**只给文字提示**，不给任何伪代码。

## 常见坑

| 坑 | 后果 | 对策 |
|---|---|---|
| SVG 几何属性配 CSS transition | 动画不生效 | 用 `<g style="transform">` 或重绘 |
| 颜色类名（如 `c-purple`）未实现 | 形状变黑、深色主题看不见 | 每个形状显式写 `fill` |
| 手写 .ipynb JSON | 转义错误、Jupyter 打不开 | 用生成器 + `json.dump` |
| 演示代码引用了未声明的依赖 | 学习者一跑就 traceback | 依赖写进 pyproject；导入用 try/except + 降级提示 |
| Notebook 相对路径 `../data/` | 校验时找不到文件 | 校验脚本先 `chdir` 到 notebooks/ |
| 凭印象写超参 | 与官方实现对不上 | 读源码，把真实数值写进课程 |
| 只给结论不给验证 | 学习者不知道自己写对没有 | 每个留白后面加测试块 + 章末 summary() |
| 测试块在没写代码时抛 NameError | 一运行就炸，学习者不敢点 | `check()` 捕获 NameError → 打印「⏸ 未实现」 |
| 测试断言过严 / 测内部实现 | 正确写法也过不了 | 只断言形状、不变量、与独立公式的一致性 |
| 测试本身写错（公式抄错、布局搞混） | 学习者写对了却被判错 | 用 `verify_tests.py` + 答案实现反向校验 |
| 跨章依赖导致测试失败 | 前面小 bug 让本章误判 | 用 `deps()` 给精简参考实现 |
| 官方配图只放进网页 | Notebook 里没有视觉锚点 | 用 `img()` 同时插进网页和 Notebook |
| 网页放进 `/docs` 再用 Pages 托管 | `images/` 必须搬进 docs，Notebook 的 `../images/` 失效 | **网页放仓库根目录**，根目录就是站点根 |
| Notebook 链接用相对路径 | Pages 不能渲染 `.ipynb`，点了 404 | 指向 GitHub 的 `blob/<branch>/notebooks/xxx.ipynb` |
| 仓库地址散落在 15 个 HTML 里 | 改名要改 15 处 | 只在 `chapters.js` 写一次，用 `set_repo.py` 同步 |
| 校验脚本用相对 cwd 的路径 | 换个目录跑就找不到文件 | 用 `path.dirname(__file__)` / `import.meta.url` 定位 |

## 资源

### scripts/
- `notebook_builder.py` —— Notebook 生成工具。内容单元：`md / code / blank / img / header / goals / part1 / part2 / part3 / save`；
  测试单元：`testkit / test / summary_cell / deps`。直接 import 使用。
- `validate_notebooks.py` —— 校验 JSON / nbformat 结构 / 每个代码单元语法。
- `run_notebooks.py` —— 顺序执行所有非留白单元（自动跳过含「你的实现」的留白单元），
  同时验证测试块在「未实现」时不会抛异常。
- `verify_tests.py` —— **答案反向校验**：给定项目外的一份参考实现，跑通所有测试块，
  确认测试本身正确。用法 `python verify_tests.py <notebooks_dir> <answers.py>`。
- `set_repo.py` —— 把 `assets/chapters.js` 里的仓库坐标同步到所有静态 HTML 的导航
  （「配套 Notebook」指向 GitHub 的 `.ipynb`）。用法 `python set_repo.py <owner>/<repo> [branch]`。
- `publish.py` —— 一键建仓 + 推送 + 开启 GitHub Pages（source = 当前分支 / 根目录）。
  用法 `python publish.py <owner>/<repo>`，依赖已登录的 `gh`。
- `check_html_js.mjs` —— 抽取网页内联 `<script>`，用 `new Function(code)` 只编译不执行，秒级抓语法错。

### references/
- `html-animation-patterns.md` —— 动画技术选型、SVG/CSS 陷阱、页面骨架模板、CSS 组件清单。
- `notebook-authoring.md` —— 三段式结构规范、留白模板、生成器用法、校验流程。

### assets/
- `course-style.css` —— 浅色主题教学样式（card / callout / stage / btn / pager / 动画辅助类）。
- `course-common.js` —— `svgEl()` SVG 助手 + `Player` 帧播放器 + `wireControls()` + 侧边栏高亮。
- `course-chapters.js` —— `CHAPTERS` 清单 + `bootChapter()`，驱动侧边栏与翻页导航。

### 参考实现
完整案例见 `D:\MY PY\LLM\minimind-from-scratch\`（MiniMind 从零学习，15 章 / 16 个网页 /
15 个 Notebook / 167 个代码单元，其中 36 个留白单元 + **30 个测试块**；
网页在仓库根目录，可直接用 GitHub Pages 托管）。可整体作为模板复制改造。
